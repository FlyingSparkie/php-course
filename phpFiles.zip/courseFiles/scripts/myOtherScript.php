<?PHP

function doPrint() {

print "This was printed from the myOtherScript.php";

}

?>