<?PHP
	session_start();
	session_destroy();
?>

	<html>
	<head>
	<title>Basic Login Script</title>


	</head>
	<body>




	User Logged Out

	</body>
	</html>
